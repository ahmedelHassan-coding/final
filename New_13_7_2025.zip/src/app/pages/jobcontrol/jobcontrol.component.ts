import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-jobcontrol',
  imports: [RouterLink],
  templateUrl: './jobcontrol.component.html',
  styleUrl: './jobcontrol.component.css'
})
export class JobcontrolComponent {

}
