import { Component } from '@angular/core';

@Component({
  selector: 'app-editexperinces',
  imports: [],
  templateUrl: './editexperinces.component.html',
  styleUrl: './editexperinces.component.css'
})
export class EditexperincesComponent {

}
