import { Component } from '@angular/core';

@Component({
  selector: 'app-parteners',
  imports: [],
  templateUrl: './parteners.component.html',
  styleUrl: './parteners.component.css'
})
export class PartenersComponent {

}
