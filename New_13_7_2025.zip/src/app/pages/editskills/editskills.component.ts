import { Component } from '@angular/core';

@Component({
  selector: 'app-editskills',
  imports: [],
  templateUrl: './editskills.component.html',
  styleUrl: './editskills.component.css'
})
export class EditskillsComponent {

}
