import { Component } from '@angular/core';

@Component({
  selector: 'app-graduate-applied-jobs',
  imports: [],
  templateUrl: './graduate-applied-jobs.component.html',
  styleUrl: './graduate-applied-jobs.component.css'
})
export class GraduateAppliedJobsComponent {

}
