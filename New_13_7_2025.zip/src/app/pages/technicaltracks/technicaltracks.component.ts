import { Component } from '@angular/core';

@Component({
  selector: 'app-technicaltracks',
  imports: [],
  templateUrl: './technicaltracks.component.html',
  styleUrl: './technicaltracks.component.css'
})
export class TechnicaltracksComponent {

}
