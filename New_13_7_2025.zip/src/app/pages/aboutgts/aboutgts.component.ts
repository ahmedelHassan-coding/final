import { Component } from '@angular/core';

@Component({
  selector: 'app-aboutgts',
  imports: [],
  templateUrl: './aboutgts.component.html',
  styleUrl: './aboutgts.component.css'
})
export class AboutgtsComponent {

}
